package xmu.mystore.orderindex.tangkai.model;

/**
 * @author tangkai
 * @data 2017年6月2日--下午4:18:04
 */
public class User {
	private long user_id;
	private String user_name;
	private String mobile_phone;
	public long getUser_id() {
		return user_id;
	}
	public void setUser_id(long user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getMobile_phone() {
		return mobile_phone;
	}
	public void setMobile_phone(String mobile_phone) {
		this.mobile_phone = mobile_phone;
	}

	
}
