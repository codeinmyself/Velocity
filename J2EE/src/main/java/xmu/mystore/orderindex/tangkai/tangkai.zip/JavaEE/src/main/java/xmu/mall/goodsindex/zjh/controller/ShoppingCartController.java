package xmu.mall.goodsindex.zjh.controller;

import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import xmu.mall.goodsindex.zjh.model.AjaxReturnResult;
import xmu.mall.goodsindex.zjh.model.OrderInfo;
import xmu.mall.goodsindex.zjh.model.ShoppingCart;
import xmu.mall.goodsindex.zjh.service.IShoppingCartService;
import xmu.mystore.goodsmgt.wcf.model.Goods;
import xmu.mystore.goodsmgt.wcf.service.outter.IGoodsMapper;
import xmu.mystore.orderindex.tangkai.model.Order;
import xmu.mystore.orderindex.tangkai.model.OrderGoods;
import xmu.mystore.orderindex.tangkai.model.User;
import xmu.mystore.orderindex.tangkai.model.UserAddress;
import xmu.mystore.orderindex.tangkai.service.OrderGoodsService;
import xmu.mystore.orderindex.tangkai.service.OrderService;
import xmu.mystore.orderindex.tangkai.service.UserService;

@Controller
@RequestMapping(value="/cart")
public class ShoppingCartController {
	
	@Autowired
	@Qualifier("ShoppingCartService")
	private IShoppingCartService shoppingCartService;

	
	
	/**
	 * 跳转到购物车主页
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/index",method=RequestMethod.GET)
	public String cartIndex(Model model,HttpSession session)
	{
		Long userId=Long.valueOf(session.getAttribute("userId").toString());
		model.addAttribute("shoppingCartList",shoppingCartService.getShoppingCartListByUserId(userId));
		return "zjh/cartIndex";
	}
	
	/**
	 * 添加购物车
	 * @param shopppingCart
	 * @param model
	 * @param session
	 * @return
	 */
	@RequestMapping(value="/add",method=RequestMethod.POST)
	@ResponseBody
	public AjaxReturnResult addShoppingCart(
			@ModelAttribute ShoppingCart shopppingCart,
			Model model,
			HttpSession session)
	{
		//需要session
		shopppingCart.setUserId(Long.valueOf(session.getAttribute("userId").toString()));
		return shoppingCartService.add(shopppingCart);
	}
	
	/**
	 * 删除购物车
	 * @param shoppingCarts
	 * @return
	 */
	@RequestMapping(value="/delete",method=RequestMethod.POST)
	@ResponseBody
	public AjaxReturnResult deleteShoppingCarts(
			@RequestBody List<ShoppingCart> shoppingCarts
			)
	{
		return shoppingCartService.delete(shoppingCarts);
	}
	
	/**
	 * 更新购物车
	 * @param shoppingCarts
	 * @return
	 */
	@RequestMapping(value="/update",method=RequestMethod.POST)
	@ResponseBody
	public AjaxReturnResult updateShoppingCarts(
			@RequestBody List<ShoppingCart> shoppingCarts
			)
	{
		return shoppingCartService.update(shoppingCarts);
	}
}
