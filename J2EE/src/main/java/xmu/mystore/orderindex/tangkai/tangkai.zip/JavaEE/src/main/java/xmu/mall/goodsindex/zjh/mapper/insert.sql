-- ----------------------------
-- Records of shoppingcart
-- ----------------------------
INSERT INTO `142532_shoppingcart` VALUES ('4', '1', '28', '8');
INSERT INTO `142532_shoppingcart` VALUES ('11', '1', '138', '4');
INSERT INTO `142532_shoppingcart` VALUES ('12', '1', '151', '2');
INSERT INTO `142532_shoppingcart` VALUES ('15', '1', '125', '23');
INSERT INTO `142532_shoppingcart` VALUES ('16', '1', '55', '1');
