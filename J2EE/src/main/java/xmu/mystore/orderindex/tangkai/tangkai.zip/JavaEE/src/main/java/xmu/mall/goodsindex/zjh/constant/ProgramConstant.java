package xmu.mall.goodsindex.zjh.constant;

/**
 * 定义程序常量
 * @author ZengJieHang
 *
 */
public class ProgramConstant 
{
	public static int INDEX_PIGE_SIZE=8;	//每一页的大小
	public static int INDEX_INITIAL_PAGE=0;	//初始页码
}
